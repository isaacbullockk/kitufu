# Kitufu Railway Deployment Guide

## STEP 1: Push Code to GitHub

```bash
# On your local machine
cd /path/to/kitufu

git init
git add .
git commit -m "Ready for Railway deployment"

# Create repo on github.com (name it "kitufu")
git remote add origin https://github.com/YOUR_USERNAME/kitufu.git
git branch -M main
git push -u origin main
```

## STEP 2: Deploy on Railway

1. Go to https://railway.app
2. Click **"New Project"**
3. Select **"Deploy from GitHub repo"**
4. Choose your **kitufu** repo
5. Click **"Deploy"**
6. Railway will auto-detect and build

## STEP 3: Add Environment Variables

In Railway dashboard → Your Project → Variables:

```
DATABASE_URL=                (Railway auto-provisions MySQL)
VITE_KIMI_AUTH_URL=https://kimi.moonshot.cn
VITE_APP_ID=kitufu-residences
FLUTTERWAVE_PUBLIC_KEY=FLWPUBK_TEST-xxxxxxxx
FLUTTERWAVE_SECRET_KEY=FLWSECK_TEST-xxxxxxxx
SENDGRID_API_KEY=SG.xxxxxxxx
FROM_EMAIL=hello@kitufu.com
JWT_SECRET=your-random-secret-key-here
```

## STEP 4: Generate Domain

Project Settings → Domains → Generate Domain

Copy the Railway URL (e.g., `kitufu-production.up.railway.app`)

## STEP 5: Update Namecheap DNS

In Namecheap Advanced DNS:

1. Delete the old URL Redirect for `@`
2. Add **A Record**:
   - Host: `@`
   - Value: (Railway's IP address from project settings)
3. Add **CNAME Record**:
   - Host: `www`
   - Value: `kitufu-production.up.railway.app`

## STEP 6: Google Search Console Verification

1. Go to https://search.google.com/search-console
2. Click **"Add Property"**
3. Enter: `kitufu.com`
4. Choose verification method:
   - **HTML file upload** OR
   - **DNS record** (easiest - add TXT record in Namecheap)
5. Follow Google's instructions
